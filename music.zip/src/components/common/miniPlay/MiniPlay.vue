<template>
  <div
    v-if="playData.cover"
    class="mini-play"
    @click="$store.commit('setPlayStatus',{showPlayPage:true})"
  >
    <div class="cover">
      <CoverRotate border="3px" :coverURL="playData.cover"></CoverRotate>
    </div>
    <div class="song">
      <span>{{playData.name}}</span>
      <span>{{playData.singer}}</span>
    </div>
    <div class="play" @click.stop="isPlay">
      <i v-show="!status" class="iconfont icon-bofang"></i>
      <i v-show="status" class="iconfont icon-zanting1"></i>
    </div>
    <div class="list" @click.stop="showList=!showList">
      <i class="iconfont icon-caidan1"></i>
    </div>
    <div @touchmove.prevent v-show="showList" class="play-list">
      <PlayList h="330" @play-lately="playSong" :content="latelyList"></PlayList>
    </div>
  </div>
</template>
<script>
import { mapState } from "vuex";
import CoverRotate from "../../playPage/coverRotate/CoverRotate";
import PlayList from "@common/playList/PlayList";

export default {
  name: "MiniPlay",
  data() {
    return {
      status: true,
      showList: false
    };
  },
  computed: {
    ...mapState({
      playData: state => state.playPage.playData,
      latelyList: state => state.playPage.latelyList
    })
  },
  methods: {
    isPlay() {
      (this.status = !this.status), console.log(2);
      this.$store.commit("setPlayStatus", {
        play: this.status,
        effect: this.status
      });
    },
    playSong(song) {
      this.$store.commit("setPlayStatus", {
        data: song
      });
    }
  },
  components: {
    CoverRotate,
    PlayList
  }
};
</script>
<style scoped lang="less">
@import "@less/mixins";

.mini-play {
  width: 100%;
  height: 60px;
  font-size: 14px;
  background: #fff;
  position: fixed;
  left: 0;
  bottom: 0;
  display: flex;
  color: #323030;
  justify-content: space-around;
  align-items: center;

  .cover {
    width: 50px;
    height: 50px;
  }

  .song {
    span {
      display: block;
    }

    span:nth-child(2) {
      font-size: 12px;
      color: #666666;
    }
  }

  .play {
    .iconfont {
      font-size: 28px;
      vertical-align: middle;
    }
  }

  .list {
    .iconfont {
      font-size: 28px;
      vertical-align: middle;
    }
  }
  .play-list {
    width: 300px;
    height: 330px;
    position: fixed;
    bottom: 60px;
    right: 0;
    background: #f2f3f4;
    overflow: hidden;
  }
}
</style>