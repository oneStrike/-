<template>
  <!-- @touchmove.prevent 阻止底层内容仍然可以滚动-->
  <aside @touchmove.prevent class="lately-container">
    <div class="lately-content">
      <header class="title">
        <HeaderNav>
          <!--        //=>使用自定义事件通知父组件，隐藏历史播放页面-->
          <div class="left" @click="$emit('hide-lately-play')">
            <i class="iconfont icon-fanhui"></i>
          </div>
          <div class="center" :class="{'active':active}" @click="active=true">
            <h3>播放列表</h3>
          </div>
          <div class="right" :class="{'active':!active}" @click="active=false">
            <h3>云端历史</h3>
          </div>
        </HeaderNav>
      </header>
      <section v-show="active" class="lately-list">
        <PlayList @play-lately="playLately" :content="latelyList||[]" substitute="还没有播放过的曲目哦"></PlayList>
      </section>
      <section v-show="!active" class="lately-list">
        <PlayList :content="[]" substitute="登录才可以使用更多的功能哦"></PlayList>
      </section>
    </div>
  </aside>
</template>

<script>
import { mapState } from "vuex";
import HeaderNav from "../headerNav/HeaderNav";
import PlayList from "../playList/PlayList";

export default {
  name: "LatelyPlayList",
  data() {
    return {
      active: true
    };
  },
  props: {
    initPosition: Boolean
  },
  computed: {
    ...mapState({
      latelyList: state => state.playPage.latelyList,
      playData: state => state.playPage.playData,
      isPlay: state => state.playPage.isPlay
    })
  },
  methods: {
    playLately(song) {
      //=>如果当前的歌曲正在播放，并且点击的歌曲与当前播放的歌曲为同一首，则直接返回，不做处理
      if (this.playData.id === song.id && this.isPlay) return;
      this.$store.commit("setPlayStatus", {
        data: song,
        play: true
      });
    }
  },
  components: {
    HeaderNav,
    PlayList
  }
};
</script>

<style scoped lang="less">
@import "@less/mixins";

.lately-container {
  width: 100%;
  height: 100%;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 200;
  background: rgba(0, 0, 0, 0.2);

  .lately-content {
    width: 70%;
    height: 100%;
    background: #fff;

    .title {
      width: 100%;
      height: 45px;
      background: @themecolor;

      .center,
      .right {
        flex: 3;
        text-align: center;
        line-height: 45px;
        position: relative;
        color: @fontcolor;
      }

      .left {
        flex: 1;
        text-align: center;
        line-height: 45px;
        color: @fontcolor;
      }

      .active::after {
        content: "";
        border-bottom: 2px solid @fontcolor;
        width: 60px;
        position: absolute;
        left: 50%;
        margin-left: -30px;
        bottom: 5px;
      }
    }
  }

  .lately-list {
    color: #323030;
  }
}
</style>