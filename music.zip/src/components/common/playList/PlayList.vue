<template>
  <div class="list-container">
    <div class="title">
      <i class="iconfont icon-bofang"></i>
      <span>播放全部</span>
      <span class="count">（共{{content.length}}首）</span>
    </div>
    <div ref="content" :style="{height:`${h}px`}" v-if="content.length!==0" class="content">
      <ul :style="{height:`${(Number(h)+1)+'px'}`}" ref="list" class="list-content">
        <li
          @click="playLately(song)"
          v-for="(song,index) in content"
          :key="song.id"
          class="content-detail"
          :class="{'active-play':playData.id === song.id}"
        >
          <span class="count">{{index+1}}</span>
          <div class="cantlet">
            <span class="name">{{song.name}}</span>
            <span class="singer">{{song.singer}}</span>
          </div>
        </li>
      </ul>
    </div>
    <div v-else class="content">
      <span>{{substitute}}</span>
    </div>
  </div>
</template>

<script>
import { mapState } from "vuex";
import BScroll from "better-scroll";

export default {
  name: "PlayList",
  props: {
    content: {
      type: Array,
      required: false
    },
    substitute: {
      type: String,
      required: false
    },
    h: {
      type: String
    }
  },
  computed: {
    ...mapState({
      playData: state => state.playPage.playData
    })
  },
  methods: {
    playLately(song) {
      this.$emit("play-lately", song);
    }
  },
  mounted() {
    this.$nextTick(() => {
      console.log;
      new BScroll(".content", {
        click: true
      });
    });
  }
};
</script>

<style scoped lang="less">
@import "@less/mixins";

.list-container {
  width: 100%;
  height: 100%;
  font-size: 16px;

  .title {
    width: 100%;
    height: 45px;
    font-size: 14px;
    line-height: 45px;

    .iconfont {
      font-size: 20px;
      vertical-align: middle;
      margin: 0 15px;
    }

    .count {
      font-size: 12px;
    }
  }
  .content {
    position: relative;
    .list-content {
      width: 100%;
      background: #f2f3f4;
      font-size: 14px;
      text-align: center;
      float: left;

      .content-detail {
        height: 60px;
        .bottom-border-1px(#b3aeae);

        .count {
          width: 20%;
          height: 60px;
          text-align: center;
          line-height: 60px;
          float: left;
          font-size: 20px;
          color: #323030;
        }

        .cantlet {
          width: 80%;
          height: 40px;
          text-align: left;
          position: relative;
          top: 50%;
          transform: translate(0, -50%);
          display: flex;
          flex-direction: column;
          justify-content: center;

          .name {
            width: 100%;
            font-size: 16px;
            flex: 1;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
          }

          .singer {
            font-size: 12px;
            flex: 1;
            color: #857979;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
          }
        }
      }
    }
    & .active-play {
      color: @themecolor;
    }
  }
}
</style>