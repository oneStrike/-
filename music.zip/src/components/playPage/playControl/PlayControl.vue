<template>
  <div class="play-control" @click="playControl">
    <div class="play-mode">
      <i v-show="mode===1" class="iconfont icon-shunxubofang"></i>
      <i v-show="mode===2" class="iconfont icon-danquxunhuan"></i>
      <i v-show="mode===3" class="iconfont icon-suiji"></i>
    </div>
    <div class="last-song">
      <i class="iconfont icon-shangyiqu"></i>
    </div>
    <div class="play-status">
      <i v-show="isPlay" class="iconfont icon-zanting1"></i>
      <i v-show="!isPlay" class="iconfont icon-bofang"></i>
    </div>
    <div class="next-song">
      <i class="iconfont icon-xiayiqu"></i>
    </div>
    <div class="collect">
      <i class="iconfont icon-aixin"></i>
    </div>
  </div>
</template>

<script>
import { mapState } from "vuex";

export default {
  name: "PlayControl",
  data() {
    return {
      mode: 1,
      random: null,
      repeatRandom: null
    };
  },
  props: {
    playTag: HTMLAudioElement
  },
  computed: {
    ...mapState({
      isPlay: state => state.playPage.isPlay,
      latelyList: state => state.playPage.latelyList,
      playData: state => state.playPage.playData,
      playMode: state => state.playPage.playMode
    })
  },
  methods: {
    setPlayStatus(i, condition) {
      //=>如果播放列表只有一首歌，不做任何处理
      if (this.latelyList.length === 1) return;
      condition ? (i = i - 1) : (i = i + 1);
      this.$store.commit("setPlayStatus", {
        play: true,
        effect: true,
        data: this.latelyList[i]
      });
    },
    //=>自动或手动触发下一首歌曲的播放
    playNextSong() {
      for (let i = 0; i < this.latelyList.length; i++) {
        if (this.latelyList[i].id === this.playData.id) {
          i === this.latelyList.length - 1 ? (i = -1) : null;
          this.setPlayStatus(i);
          return;
        }
      }
    },
    //=>随机播放
    randomPlay() {
      this.random = Math.floor(Math.random() * this.latelyList.length);
      if (this.random === this.repeatRandom) {
        //=>利用递归，确保不会播放相同的歌曲
        this.randomPlay();
        return;
      }
      this.setPlayStatus(
        this.random,
        this.random === this.latelyList.length - 1
      );
    },
    //=>利用事件冒泡的机制统一控制播放状态
    playControl(e) {
      let target = e.target;
      if (
        target.className === "play-status" ||
        target.parentElement.className === "play-status"
      ) {
        //=>暂停和播放
        if (this.isPlay) {
          this.$store.commit("setPlayStatus", {
            play: false,
            effect: false
          });
        } else {
          this.$store.commit("setPlayStatus", {
            play: true,
            effect: true
          });
        }
      } else if (
        target.className === "last-song" ||
        target.parentElement.className === "last-song"
      ) {
        //=>上一曲
        for (let i = 0; i < this.latelyList.length; i++) {
          if (this.latelyList[i].id === this.playData.id) {
            i === 0 ? (i = this.latelyList.length) : null;
            this.setPlayStatus(i, true);
            return;
          }
        }
      } else if (
        target.className === "next-song" ||
        target.parentElement.className === "next-song"
      ) {
        //=>下一曲
        this.playNextSong();
      } else if (
        target.className === "play-mode" ||
        target.parentElement.className === "play-mode"
      ) {
        //=>播放模式
        this.mode += 1;
        if (this.mode > 3) {
          this.mode = 1;
        }
      }
    }
  },
  watch: {
    playTag() {
      //=>初始播放模式为列表循环
      this.$nextTick(() => {
        this.playTag.addEventListener("ended", () => {
          //=>播放结束后只有一首歌，并且播放模式不是单曲循环，就直接停止播放
          if (this.latelyList.length === 1 && this.mode !== 2) {
            this.$store.commit("setPlayStatus", {
              play: false,
              effect: false
            });
          }
          if (this.mode === 1) {
            //=>列表循环
            this.playNextSong();
          } else if (this.mode === 2) {
            //=>单曲循环
            this.playTag.currentTime = 0;
            this.playTag.play();
          } else if (this.mode === 3) {
            //=>随机播放
            this.randomPlay();
          }
        });
      });
    }
  }
};
</script>

<style scoped lang="less">
.play-control {
  width: 100%;
  height: 50px;
  position: absolute;
  bottom: 30px;
  display: flex;
  justify-content: space-around;
  font-size: 18px;
  line-height: 50px;

  .play-status {
    .iconfont {
      font-size: 40px;
    }
  }

  .iconfont {
    width: 100%;
    height: 100%;
    display: inline-block;
    font-size: 24px;
  }
}
</style>