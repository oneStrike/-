<template>
  <div @click="$emit('hide-lyric')" id="lyric-container">
    <ul ref="lyricContent" class="lyric-content">
      <li
        ref="lyricDetail"
        :class="{'active':line-1===index}"
        v-for="(lyric,index) in reLyric"
        :key="index"
      >
        <p>{{lyric}}</p>
      </li>
    </ul>
  </div>
</template>

<script>
import { mapState } from "vuex";
import BScroll from "better-scroll";

export default {
  name: "Lyric",
  data() {
    return {
      audio: null,
      lyricTime: [],
      line: 0,
      curTime: 0
    };
  },
  props: {
    activeLine: {
      type: [Number, String],
      default: 2
    }
  },
  computed: {
    ...mapState({
      lyric: state => state.playPage.lyric,
      lyricLine: state => state.playPage.lyricLine
    }),
    //=>解析歌词
    reLyric() {
      if (this.lyric) {
        this.lyric.replace(/(\[.*?]\s)(?=\[)/g, "").replace(/\[.*?]/g, time => {
          time = time.split(/\D/);
          time = time.splice(1, 3);
          time = parseInt(time[0]) * 60 + parseInt(time[1]) + "." + time[2];
          this.lyricTime.push(time);
        });
      }
      return this.lyric.split(/\s*\n*\[.*?]\s*/).filter(v => !!v);
    }
  },
  mounted() {
    this.$bus.$on("audio", a => {
      a.addEventListener("timeupdate", () => {
        //=>跳转歌曲，改变歌词
        if (a.currentTime < this.curTime || a.currentTime - this.curTime > 1) {
          this.curTime = a.currentTime;
          this.skipLyric();
          return;
        } else if (this.lyricTime[this.line] <= a.currentTime) {
          this.line++;
          if (this.line >= this.activeLine) {
            this.$refs.lyricContent.style.transform = `translateY(${-this.$refs
              .lyricDetail[this.line - 1].offsetHeight *
              (this.line - this.activeLine)}px)`;
          }
          this.curTime = a.currentTime;
        }
        this.curTime = a.currentTime;
      });
      a.addEventListener("ended", this.initLyric);
      a.addEventListener("durationchange", this.initLyric);
    });
    new BScroll("#lyric-container", {
      click: true
    });
  },
  methods: {
    initLyric() {
      this.$refs.lyricContent.style.transform = "translateY(0)";
      this.line = 0;
      this.lyricTime = [];
      this.curTime = 0;
    },
    skipLyric() {
      for (let i = 0; i < this.lyricTime.length; i++) {
        if (this.curTime <= this.lyricTime[i]) {
          this.line = i;
          this.$refs.lyricContent.style.transform = `translateY(${-this.$refs
            .lyricDetail[this.line].offsetHeight *
            (this.line - this.activeLine)}px)`;
          return;
        }
      }
    }
  },
  watch: {
    lyricTime: {
      handler: function() {}
    },
    activeLine: {
      handler: function() {
        if (this.line >= this.activeLine) {
          this.$refs.lyricContent.style.transform = `translateY(${-this.$refs
            .lyricDetail[this.line - 1].offsetHeight *
            (this.line - this.activeLine)}px)`;
        }
      }
    }
  }
};
</script>

<style scoped lang="less">
@import "@less/mixins";

#lyric-container {
  width: 100%;
  height: 450px;
  margin-top: 30px;
  overflow: hidden;
  text-align: center;

  ul {
    transition: all 200ms linear;
    li {
      height: 35px;
    }
  }

  .active {
    font-size: 16px;
    color: @themecolor;
    transition: all 200ms linear;
  }
}
</style>