<template>

</template>

<script>
  export default {
    name: "Search"
  }
</script>

<style scoped>

</style>