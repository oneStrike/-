<template>
  <div id="profile"></div>
</template>

<script>
  export default {
    name: "Profile"
  }
</script>

<style scoped>

</style>