<<<<<<< HEAD
# music

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
=======
# -
使用VUE全家桶仿制的网易云音乐
>>>>>>> 1cbcb36982e42d4b7de3afe8a97a225d07f61f52
